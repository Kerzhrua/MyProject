### 0.1.0-alpha - TBA
* With Nvidia CUDA 7.0.28
* Initial version
