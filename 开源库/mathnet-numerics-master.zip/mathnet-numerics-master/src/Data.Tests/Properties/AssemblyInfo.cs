﻿using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: Guid("bb41bee6-eb4c-48c9-8edd-7a5ae2422567")]
