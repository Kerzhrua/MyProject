﻿namespace MathNet.Numerics

open System.Runtime.InteropServices

[<assembly: ComVisible(false)>]
[<assembly: Guid("C9AA6156-F799-42E4-B50D-2E88AD7D1750")>]

()
